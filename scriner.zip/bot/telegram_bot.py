"""
Telegram бот для уведомлений о китовых сделках
"""

import asyncio
from typing import Optional
from datetime import datetime

from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from loguru import logger

from models.alert import Alert


class WhaleAlertBot:
    """
    Telegram бот для отправки алертов
    
    Функции:
    - Отправка уведомлений о китовых сделках
    - Настройка порогов через команды
    - Статистика и мониторинг
    """
    
    def __init__(
        self,
        token: str,
        admin_id: int,
        screener=None
    ):
        self.token = token
        self.admin_id = admin_id
        self.screener = screener
        
        self.bot: Optional[Bot] = None
        self.dispatcher: Optional[Dispatcher] = None
        self._running = False
        
        # Cooldown для алертов
        self._last_alert_time = {}
        self._cooldown_seconds = 5
    
    async def initialize(self):
        """Инициализация бота"""
        self.bot = Bot(token=self.token, parse_mode="HTML")
        self.dispatcher = Dispatcher()
        
        # Регистрация хендлеров
        self._register_handlers()
        
        # Проверка подключения
        try:
            await self.bot.get_me()
            logger.info("✅ Telegram бот подключен")
        except Exception as e:
            logger.error(f"❌ Ошибка подключения к Telegram: {e}")
            raise
    
    def _register_handlers(self):
        """Регистрация обработчиков команд"""
        
        @self.dispatcher.message(Command("start"))
        async def cmd_start(message: types.Message):
            if message.from_user.id != self.admin_id:
                return
            await message.answer(
                "🐋 <b>Whale Screener Bot</b>\n\n"
                "Команды:\n"
                "/status - Статус системы\n"
                "/set_threshold <amount> - Изменить порог ($)\n"
                "/pairs - Отслеживаемые пары\n"
                "/logs - Последние логи\n"
                "/help - Помощь"
            )
        
        @self.dispatcher.message(Command("status"))
        async def cmd_status(message: types.Message):
            if message.from_user.id != self.admin_id:
                return
            
            if self.screener:
                whale_stats = self.screener.whale_detector.get_stats()
                pairs_count = len(self.screener.config.get('tracked_pairs', []))
                threshold = self.screener.config.get('whale_detection', {}).get('min_volume_usd', 50000)
            else:
                whale_stats = {}
                pairs_count = 0
                threshold = 50000
            
            await message.answer(
                "📊 <b>Статус системы</b>\n\n"
                f"✅ Бот активен\n"
                f"📈 Пар: {pairs_count}\n"
                f"💰 Порог: ${threshold:,}\n"
                f"🐋 Китов найдено: {whale_stats.get('whale_count', 0)}\n"
                f"💵 Общий объём: ${whale_stats.get('total_volume_usd', 0):,.2f}"
            )
        
        @self.dispatcher.message(Command("set_threshold"))
        async def cmd_set_threshold(message: types.Message):
            if message.from_user.id != self.admin_id:
                return
            try:
                amount = int(message.text.split()[1])
                if self.screener:
                    self.screener.update_config({
                        'whale_detection': {'min_volume_usd': amount}
                    })
                await message.answer(f"✅ Порог установлен: ${amount:,}")
            except (IndexError, ValueError):
                await message.answer("❌ Использование: /set_threshold 50000")
        
        @self.dispatcher.message(Command("pairs"))
        async def cmd_pairs(message: types.Message):
            if message.from_user.id != self.admin_id:
                return
            
            if self.screener:
                pairs = self.screener.config.get('tracked_pairs', [])
            else:
                pairs = ['BTC/USDT', 'ETH/USDT']
            
            pairs_list = "\n".join(f"• {p}" for p in pairs)
            await message.answer(f"📈 <b>Отслеживаемые пары:</b>\n\n{pairs_list}")
        
        @self.dispatcher.message(Command("logs"))
        async def cmd_logs(message: types.Message):
            if message.from_user.id != self.admin_id:
                return
            
            try:
                with open('logs/alerts.log', 'r', encoding='utf-8') as f:
                    lines = f.readlines()[-10:]  # Последние 10 записей
                
                if lines:
                    logs = "\n".join(lines)
                    await message.answer(f"📝 <b>Последние алерты:</b>\n\n<code>{logs}</code>")
                else:
                    await message.answer("📝 Алёртов пока нет")
            except FileNotFoundError:
                await message.answer("📝 Файл логов не найден")
        
        @self.dispatcher.message(Command("help"))
        async def cmd_help(message: types.Message):
            await message.answer(
                "📚 <b>Помощь</b>\n\n"
                "<b>Команды:</b>\n"
                "/start - Запустить бота\n"
                "/status - Статус системы\n"
                "/set_threshold <amount> - Порог в USD\n"
                "/pairs - Список пар\n"
                "/logs - Последние 10 логов\n"
                "/help - Эта справка\n\n"
                "<b>Примеры:</b>\n"
                "/set_threshold 100000\n"
            )
    
    async def send_alert(self, alert: Alert):
        """
        Отправка алерта в Telegram
        
        Args:
            alert: Объект алерта
        """
        # Проверка cooldown
        ticker = alert.pair
        now = datetime.now()
        
        if ticker in self._last_alert_time:
            delta = (now - self._last_alert_time[ticker]).total_seconds()
            if delta < self._cooldown_seconds:
                return  # Пропускаем частые алерты
        
        self._last_alert_time[ticker] = now
        
        # Форматирование сообщения
        message = alert.format_message()
        
        # Кнопки с ссылками
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📊 График",
                    url=f"https://www.tradingview.com/chart/?symbol={alert.pair.replace('/', '')}"
                ),
                InlineKeyboardButton(
                    text="🔗 Биржа",
                    url=alert._get_exchange_url()
                )
            ]
        ])
        
        try:
            await self.bot.send_message(
                chat_id=self.admin_id,
                text=message,
                reply_markup=keyboard
            )
            logger.debug(f"📤 Алерт отправлен: {alert.pair}")
        except Exception as e:
            logger.error(f"❌ Ошибка отправки алерта: {e}")
    
    async def start(self):
        """Запуск бота"""
        logger.info("🤖 Запуск Telegram бота...")
        self._running = True
        await self.dispatcher.start_polling(self.bot)
    
    async def stop(self):
        """Остановка бота"""
        self._running = False
        if self.bot:
            await self.bot.session.close()
            await self.bot.close()
        logger.info("🛑 Telegram бот остановлен")