# Crypto Screener React

React/Mantine версия крипто-скринера по мотивам предоставленного UI дизайна.

## Структура проекта

```
src/
├── app/
│   ├── layout.tsx      # Root layout с MantineProvider
│   ├── page.tsx        # Главная страница
│   └── globals.css     # Глобальные стили
├── components/
│   ├── Header.tsx      # Хедер с выбором биржи, режима, интервала
│   ├── ChartCard.tsx   # Компонент карточки графика
│   ├── SymbolSearch.tsx    # Поиск и добавление тикеров
│   ├── StatsRow.tsx        # Строка статистики
│   ├── Legend.tsx          # Легенда
│   ├── ThemeToggle.tsx     # Переключатель темы
│   └── ExportCSV.tsx       # Экспорт данных в CSV
├── hooks/
│   ├── useBinance.ts       # Хуки для работы с API Binance
│   └── useLocalStorage.ts  # Хук для сохранения в localStorage
└── types/
    └── index.ts        # TypeScript типы
```

## Установка

```bash
npm install
# или
yarn install
```

## Запуск

```bash
npm run dev
```

## Зависимости

- Next.js 14
- React 18
- Mantine UI 7
- klinecharts (графики)
- Tabler Icons
- Axios

## API

Приложение использует публичное API Binance:
- Futures: `https://fapi.binance.com`
- Spot: `https://api.binance.com`

## Функции

- Выбор биржи (Binance, ByBit, OKX, Gate.io, MEXC, BitGet, KuCoin, BingX, HTX)
- Режим: Фьючерсы / Спот
- Таймфреймы: 1м, 3м, 5м, 15м, 30м, 1ч, 2ч, 4ч, 6ч, 8ч, 12ч, 1д
- Сетка: 4 (2×2), 9 (3×3), 16 (4×4), 25 (5×5)
- Цветовая кодировка бейджей:
  - 🟢 Зеленый: положительные значения
  - 🔴 Красный: отрицательные значения
  - 🟡 Желтый: нейтральные/средние
  - ⚪ Серый: базовые метрики

## Новые функции (v1.1)

### 🔹 Сохранение настроек
Все настройки (биржа, режим, интервал, сетка, выбранные тикеры) сохраняются в localStorage.

### 🔹 Поиск тикеров
Добавлен компонент поиска для добавления любых USDT пар в скринер.

### 🔹 Переключатель темы
Кнопка 🌙/☀️ в хедере для переключения между тёмной и светлой темой.

### 🔹 Экспорт в CSV
Кнопка экспорта данных в CSV формат.

### 🔹 Обработка ошибок
Улучшена обработка ошибок API — показывается статус загрузки и ошибки на графиках.

### 🔹 Реальные данные
На графиках отображаются:
- Изменение цены за 24ч
- Объём торгов
- Диапазон цен
- Funding rate (для фьючерсов)
- Open Interest (для фьючерсов)

## Скрипты

```bash
npm run dev          # Запуск dev-сервера
npm run build        # Продакшен сборка
npm run start        # Запуск продакшен сервера
npm run lint         # ESLint проверка
npm run format       # Prettier форматирование
npm test             # Запуск тестов
npm run test:watch   # Тесты в режиме watching
```

## Тесты

```bash
npm test
```

Тесты покрывают:
- `useBinance` хуки (useTickers, useKlines)
- `useLocalStorage` хук
