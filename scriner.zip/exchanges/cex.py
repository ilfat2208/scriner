"""
Мониторинг централизованных бирж (CEX) через WebSocket
"""

import asyncio
from typing import List, Dict, Callable, Optional
import ccxt.async_support as ccxt
from loguru import logger

from models.alert import Alert, AlertType


class CEXMonitor:
    """
    Асинхронный монитор CEX бирж
    
    Поддерживает:
    - Binance
    - Bybit
    - OKX
    - Kraken
    """
    
    def __init__(
        self,
        exchanges: List[str],
        pairs: List[str],
        whale_detector,
        momentum_detector,
        on_alert: Callable
    ):
        self.exchange_names = exchanges
        self.pairs = pairs
        self.whale_detector = whale_detector
        self.momentum_detector = momentum_detector
        self.on_alert = on_alert
        
        self.exchanges: Dict = {}
        self._running = False
        self._tasks: List[asyncio.Task] = []
    
    async def initialize(self):
        """Инициализация подключений к биржам"""
        for name in self.exchange_names:
            try:
                exchange_class = getattr(ccxt, name)
                exchange = exchange_class({
                    'enableRateLimit': True,
                    'options': {'defaultType': 'future'}  # Фьючерсы по умолчанию
                })
                await exchange.load_markets()
                self.exchanges[name] = exchange
                logger.info(f"✅ {name.upper()} подключен")
            except Exception as e:
                logger.error(f"❌ Ошибка подключения к {name}: {e}")
    
    async def start(self):
        """Запуск мониторинга"""
        logger.info(f"📡 Запуск CEX мониторинга: {len(self.pairs)} пар")
        self._running = True
        
        await self.initialize()
        
        # Запуск WebSocket для каждой биржи
        for name, exchange in self.exchanges.items():
            task = asyncio.create_task(self._monitor_exchange(name, exchange))
            self._tasks.append(task)
        
        await asyncio.gather(*self._tasks, return_exceptions=True)
    
    async def _monitor_exchange(self, name: str, exchange):
        """Мониторинг конкретной биржи"""
        while self._running:
            try:
                for pair in self.pairs:
                    if not self._running:
                        break
                    
                    # Получение последних сделок через WebSocket
                    trades = await exchange.watch_trades(pair)
                    
                    for trade in trades:
                        await self._process_trade(name, pair, trade)
                        
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Ошибка {name}: {e}")
                await asyncio.sleep(5)  # Переподключение
    
    async def _process_trade(self, exchange: str, pair: str, trade: dict):
        """Обработка сделки"""
        side = trade['side']  # 'buy' или 'sell'
        amount = trade['amount']
        price = trade['price']
        volume_usd = amount * price
        
        # Проверка на китовую сделку
        is_whale = self.whale_detector.check_whale(volume_usd, side)
        
        # Проверка импульса
        is_momentum = self.momentum_detector.check_momentum(pair, volume_usd, side)
        
        if is_whale or is_momentum:
            alert = Alert(
                alert_type=AlertType.WHALE if is_whale else AlertType.MOMENTUM,
                exchange=exchange,
                pair=pair,
                side=side,
                volume_usd=volume_usd,
                amount=amount,
                price=price,
                timestamp=trade.get('timestamp', asyncio.get_event_loop().time()),
            )
            
            await self.on_alert(alert)
    
    async def stop(self):
        """Остановка мониторинга"""
        self._running = False
        
        for task in self._tasks:
            if not task.done():
                task.cancel()
        
        # Закрытие подключений
        for exchange in self.exchanges.values():
            await exchange.close()
        
        logger.info("🛑 CEX мониторинг остановлен")