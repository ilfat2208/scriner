#!/usr/bin/env python3
"""
🐋 Crypto Whale Screener
Автономная система обнаружения крупных сделок в реальном времени

Author: Senior Python Developer
Version: 2.0.0
"""

import asyncio
import signal
import sys
from pathlib import Path
from typing import List, Optional, Dict

from loguru import logger
from pydantic_settings import BaseSettings
import yaml

# Импорт компонентов
from bot.telegram_bot import WhaleAlertBot
from exchanges.cex import CEXMonitor
from exchanges.dex import DEXMonitor
from detectors.whale_detector import WhaleDetector
from detectors.momentum_detector import MomentumDetector
from utils.logger import setup_logger
from models.alert import Alert


class Settings(BaseSettings):
    """Настройки приложения из .env"""
    
    telegram_bot_token: str
    telegram_admin_id: int
    
    binance_api_key: Optional[str] = None
    binance_api_secret: Optional[str] = None
    
    eth_rpc_url: Optional[str] = None
    log_level: str = "INFO"
    
    whitelist_addresses: List[str] = []
    blacklist_addresses: List[str] = []
    
    database_url: Optional[str] = None
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


class WhaleScreener:
    """
    Основной класс скринера
    
    Управляет всеми компонентами системы:
    - Подключение к биржам (CEX + DEX)
    - Детекция китовых сделок
    - Отправка алертов в Telegram
    """
    
    def __init__(self, config_path: str = "config.yaml"):
        self.config = self._load_config(config_path)
        self.settings = Settings()
        
        # Настройка логирования
        setup_logger(self.settings.log_level)
        
        # Компоненты системы
        self.bot: Optional[WhaleAlertBot] = None
        self.cex_monitor: Optional[CEXMonitor] = None
        self.dex_monitor: Optional[DEXMonitor] = None
        self.whale_detector = WhaleDetector(
            min_volume_usd=self.config['whale_detection']['min_volume_usd'],
            whitelist=self.settings.whitelist_addresses,
            blacklist=self.settings.blacklist_addresses
        )
        self.momentum_detector = MomentumDetector(
            window_seconds=self.config['whale_detection']['momentum_window_seconds'],
            threshold_percent=self.config['whale_detection']['momentum_threshold_percent']
        )
        
        # Флаги управления
        self._running = False
        self._shutdown_event = asyncio.Event()
        
        logger.info("🐋 Whale Screener инициализирован")
    
    @staticmethod
    def _load_config(config_path: str) -> dict:
        """Загрузка конфигурации из YAML"""
        path = Path(config_path)
        if not path.exists():
            logger.warning(f"Конфиг {config_path} не найден, используем настройки по умолчанию")
            return {
                'whale_detection': {
                    'min_volume_usd': 50000,
                    'momentum_window_seconds': 60,
                    'momentum_threshold_percent': 300
                },
                'tracked_pairs': ['BTC/USDT', 'ETH/USDT'],
                'exchanges': {'cex': ['binance'], 'dex': []},
                'notifications': {'send_to_telegram': True, 'cooldown_seconds': 5},
                'filters': {'exclude_wash_trading': True}
            }
        
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    
    async def initialize(self):
        """Инициализация всех компонентов"""
        logger.info("🔧 Инициализация компонентов...")
        
        # Инициализация Telegram бота
        self.bot = WhaleAlertBot(
            token=self.settings.telegram_bot_token,
            admin_id=self.settings.telegram_admin_id,
            screener=self
        )
        await self.bot.initialize()
        
        # Инициализация мониторов бирж
        self.cex_monitor = CEXMonitor(
            exchanges=self.config['exchanges']['cex'],
            pairs=self.config['tracked_pairs'],
            whale_detector=self.whale_detector,
            momentum_detector=self.momentum_detector,
            on_alert=self._handle_alert
        )
        
        if self.settings.eth_rpc_url:
            self.dex_monitor = DEXMonitor(
                exchanges=self.config['exchanges']['dex'],
                rpc_url=self.settings.eth_rpc_url,
                whale_detector=self.whale_detector,
                on_alert=self._handle_alert
            )
        
        logger.info("✅ Все компоненты инициализированы")
    
    async def _handle_alert(self, alert: Alert):
        """
        Обработка обнаруженной китовой сделки
        
        Args:
            alert: Объект алерта
        """
        logger.warning(f"🚨 ALERT: {alert.pair} | {alert.side} | ${alert.volume_usd:,.2f}")
        
        if self.config['notifications']['send_to_telegram'] and self.bot:
            await self.bot.send_alert(alert)
    
    async def start(self):
        """Запуск скринера"""
        logger.info("🚀 Запуск Whale Screener...")
        self._running = True
        
        # Запуск бота
        bot_task = asyncio.create_task(self.bot.start())
        
        # Запуск мониторов
        cex_task = asyncio.create_task(self.cex_monitor.start())
        dex_task = None
        
        if self.dex_monitor:
            dex_task = asyncio.create_task(self.dex_monitor.start())
        
        # Ожидание сигнала остановки
        await self._shutdown_event.wait()
        
        # Остановка
        logger.info("⏹️ Остановка Whale Screener...")
        self._running = False
        
        if self.cex_monitor:
            await self.cex_monitor.stop()
        if self.dex_monitor:
            await self.dex_monitor.stop()
        if self.bot:
            await self.bot.stop()
        
        # Отмена задач
        for task in [bot_task, cex_task, dex_task]:
            if task and not task.done():
                task.cancel()
        
        logger.info("✅ Whale Screener остановлен")
    
    async def stop(self):
        """Сигнал остановки"""
        self._shutdown_event.set()
    
    def update_config(self, new_config: dict):
        """Обновление конфигурации через бота"""
        self.config.update(new_config)
        self.whale_detector.min_volume_usd = self.config['whale_detection']['min_volume_usd']
        logger.info(f"📝 Конфигурация обновлена: {new_config}")


async def main():
    """Точка входа"""
    # Проверка .env файла
    env_path = Path(".env")
    if not env_path.exists():
        print("❌ Файл .env не найден!")
        print("📝 Скопируйте .env.example в .env и заполните значения")
        sys.exit(1)
    
    screener = WhaleScreener()
    
    # Обработка сигналов ОС
    loop = asyncio.get_event_loop()
    
    def signal_handler():
        logger.info("📶 Получен сигнал остановки")
        asyncio.create_task(screener.stop())
    
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, signal_handler)
    
    try:
        await screener.initialize()
        await screener.start()
    except KeyboardInterrupt:
        logger.info("⌨️ Прервано пользователем")
    except Exception as e:
        logger.exception(f"❌ Критическая ошибка: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())