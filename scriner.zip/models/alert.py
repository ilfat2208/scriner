"""
Модель алерта
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from enum import Enum


class AlertType(Enum):
    """Тип алерта"""
    WHALE = "WHALE"
    MOMENTUM = "MOMENTUM"
    PRICE_SPIKE = "PRICE_SPIKE"


@dataclass
class Alert:
    """
    Модель алерта о китовой сделке
    
    Attributes:
        alert_type: Тип алерта
        exchange: Название биржи
        pair: Торговая пара
        side: BUY или SELL
        volume_usd: Объём в долларах
        amount: Количество токенов
        price: Цена сделки
        timestamp: Время алерта
        tx_hash: Хэш транзакции (для DEX)
    """
    alert_type: AlertType
    exchange: str
    pair: str
    side: str
    volume_usd: float
    amount: float
    price: float
    timestamp: datetime
    tx_hash: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Конвертация в словарь для отправки в Telegram"""
        return {
            'ticker': self.pair,
            'exchange': self.exchange,
            'type': self.alert_type.value,
            'side': self.side.upper(),
            'volume_usd': self.volume_usd,
            'amount': self.amount,
            'price': self.price,
            'timestamp': self.timestamp,
            'tx_hash': self.tx_hash,
            'exchange_url': self._get_exchange_url()
        }
    
    def _get_exchange_url(self) -> str:
        """Получение ссылки на биржу"""
        base_urls = {
            'binance': 'https://www.binance.com/en/trade/',
            'bybit': 'https://www.bybit.com/trade/usdt/',
            'uniswap_v3': 'https://app.uniswap.org/#/swap'
        }
        
        exchange_lower = self.exchange.lower()
        if exchange_lower in base_urls:
            symbol = self.pair.replace('/', '')
            return f"{base_urls[exchange_lower]}{symbol}"
        
        return '#'
    
    def format_message(self) -> str:
        """Форматирование сообщения для Telegram"""
        emoji = "🟢" if self.side == 'BUY' else "🔴"
        type_emoji = "🐋" if self.alert_type == AlertType.WHALE else "📈"
        
        return f"""
{emoji} <b>{type_emoji} КИТОВАЯ СДЕЛКА</b> {emoji}

<b>Тикер:</b> {self.pair}
<b>Биржа:</b> {self.exchange.upper()}
<b>Тип:</b> {self.side.upper()}
<b>Объём:</b> ${self.volume_usd:,.2f}
<b>Токены:</b> {self.amount:,.6f} {self.pair.split('/')[0]}
<b>Цена:</b> ${self.price:,.2f}

<b>Время:</b> {self.timestamp.strftime('%H:%M:%S')}
"""